<?php
/**
 * Created by PhpStorm.
 * User: Влад
 * Date: 01.12.2017
 * Time: 10:09
 */
$i = 1;
$a= "";
 do {
     echo $a . '<br>';
     $a=$a.'x';
     $i++;
 }
while ($i < 20);
