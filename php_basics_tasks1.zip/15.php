<?php
/**
 * Created by PhpStorm.
 * User: Влад
 * Date: 30.11.2017
 * Time: 19:14
 */

$arr = [2, 5, 6, 8, 2, 4, 6, 6, 4];
$count = 0;
foreach ($arr as $item)
{
    $count++;
}
echo $count;