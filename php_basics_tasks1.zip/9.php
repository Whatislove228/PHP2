<?php
/**
 * Created by PhpStorm.
 * User: Влад
 * Date: 30.11.2017
 * Time: 18:36
 */

for($i = 1;$i <= 100; $i++) {
    echo "$i</br>";
}