<?php
/**
 * Created by PhpStorm.
 * User: Влад
 * Date: 30.11.2017
 * Time: 15:33
 */

$Array = array("Вася" => 100, "Петя" => 200, "Коля" => 300);

foreach ($Array as $key => $value) {
    echo "$key зарабатывает - $value</br>";
}