<?php
/**
 * Created by PhpStorm.
 * User: Влад
 * Date: 30.11.2017
 * Time: 19:51
 */



$a = 'x';
for ($i = 1; $i<=20; $i++) {


    echo $a . '<br>';
    $a=$a.'x';

}
