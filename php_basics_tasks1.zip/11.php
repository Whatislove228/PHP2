<?php
/**
 * Created by PhpStorm.
 * User: Влад
 * Date: 30.11.2017
 * Time: 18:42
 */

for($i = 0;$i <= 100; $i++) {
    if($i%2 == 0 )
    echo "$i</br>";
}