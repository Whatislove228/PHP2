<?php
/**
 * Created by PhpStorm.
 * User: Влад
 * Date: 30.11.2017
 * Time: 18:39
 */

for($i = 11;$i <= 33; $i++) {
    echo "$i</br>";
}