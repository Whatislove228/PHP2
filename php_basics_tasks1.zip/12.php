<?php
$n = 1000;
do {
    $result = $n/2;
    echo $result;
}
while ($n > 50);